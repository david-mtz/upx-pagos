//
//  UpxPagos.h
//  UpxPagos
//
//  Created by David on 11/05/20.
//  Copyright © 2020 Upax. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for UpxPagos.
FOUNDATION_EXPORT double UpxPagosVersionNumber;

//! Project version string for UpxPagos.
FOUNDATION_EXPORT const unsigned char UpxPagosVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <UpxPagos/PublicHeader.h>


